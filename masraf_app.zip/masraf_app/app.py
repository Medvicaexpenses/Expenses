from flask import Flask, render_template, request, redirect
import sqlite3
from datetime import datetime

app = Flask(__name__)
DB_FILE = "masraf_takibi.db"

# ----- Database Initialization -----
def init_db():
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS masraflar (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                calisan_adi TEXT,
                tarih TEXT,
                saat TEXT,
                seyahat_yeri TEXT,
                musteri_adi TEXT,
                tutar REAL
            )
            """
        )

# ----- Routes -----
@app.route("/")
def index():
    with sqlite3.connect(DB_FILE) as conn:
        cur = conn.cursor()
        cur.execute(
            "SELECT * FROM masraflar ORDER BY tarih DESC, saat DESC"
        )
        masraflar = cur.fetchall()
    return render_template("index.html", masraflar=masraflar)

@app.route("/ekle", methods=["POST"])
def ekle():
    ad = request.form["calisan_adi"]
    seyahat = request.form["seyahat_yeri"]
    musteri = request.form["musteri_adi"]
    tutar = float(request.form["tutar"])

    now = datetime.now()
    tarih = now.strftime("%Y-%m-%d")
    saat = now.strftime("%H:%M")

    with sqlite3.connect(DB_FILE) as conn:
        conn.execute(
            """
            INSERT INTO masraflar (calisan_adi, tarih, saat, seyahat_yeri, musteri_adi, tutar)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (ad, tarih, saat, seyahat, musteri, tutar),
        )
    return redirect("/")

# ----- Main -----
if __name__ == "__main__":
    init_db()
    app.run(debug=True)
