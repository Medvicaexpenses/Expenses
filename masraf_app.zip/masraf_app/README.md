# Masraf Takip Sistemi (Flask + SQLite)

Bu proje, çalışanların seyahat masraflarını kaydetmek ve listelemek için geliştirilmiş basit bir **Flask** web uygulamasıdır.  
Veriler yerel bir **SQLite** veritabanında (`masraf_takibi.db`) saklanır.

## Kurulum

```bash
# Sanal ortam (opsiyonel)
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Gerekli paketleri yükleyin
pip install -r requirements.txt
```

## Çalıştırma

```bash
python app.py
```

Ardından tarayıcınızdan `http://127.0.0.1:5000` adresini açın.

## Dağıtım

- **Replit** veya **Render.com** gibi servislerde Flask uygulaması olarak kolayca yayınlayabilirsiniz.
- Dosyaları GitHub'a push edip Render.com'a bağlayarak kalıcı bir link alabilirsiniz.
  - Render ayarları için basit bir `render.yaml` dosyası eklendi.
- Kalıcı hosting için VPS (DigitalOcean, Hetzner, vb.) + Nginx + Gunicorn kurulumunu tercih edebilirsiniz.

## Dosya Yapısı

```
masraf_app/
├── app.py
├── requirements.txt
├── templates/
│   └── index.html
├── .gitignore
└── README.md
```

**İyi kodlamalar!**
